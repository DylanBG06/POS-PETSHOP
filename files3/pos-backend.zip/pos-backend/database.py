"""
Configuración de la base de datos SQLite con SQLAlchemy.
"""
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# La base de datos se guarda como un archivo local pos.db
SQLALCHEMY_DATABASE_URL = "sqlite:///./pos.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}  # Necesario para SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dependencia de FastAPI para inyectar la sesión de DB en cada request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
